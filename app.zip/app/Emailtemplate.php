<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Emailtemplate extends Model
{
	protected $table = 'av_email_template';
	public $timestamps = false;
}
