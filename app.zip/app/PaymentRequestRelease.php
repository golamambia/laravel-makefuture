<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentRequestRelease extends Model
{
	protected $table = 'av_payment_release_request_tbl';
}
