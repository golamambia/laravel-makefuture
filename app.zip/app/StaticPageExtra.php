<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StaticPageExtra extends Model
{
    // protected $table = 'av_static_page_extra';
    protected $table = 'pages_extra';
	public $timestamps = false;
}
