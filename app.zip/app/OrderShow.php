<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderShow extends Model
{
	protected $table = 'av_order_show_tbl';
}
