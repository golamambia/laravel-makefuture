<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Page extends Model
{
    // protected $table = 'av_static_page';
    protected $table = 'pages';
}
