<?php
namespace App\Http\Controllers;
use Redirect;
use Session;
use Auth;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;

use App\Page;
use App\PageExtra;
use App\User;
use App\Order;
use App\Transaction;

use Illuminate\Support\Facades\DB;

use App\Mail\WelcomeMail;
use App\Mail\UserRegistrationMailToAdmin;
use App\Mail\OrderMail;
use App\Mail\OrderMailToAdmin;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Hash;

use Stripe\Error\Card;
use Cartalyst\Stripe\Stripe;

use File;

class PageController extends Controller
{
	public function __construct()
	{

	}

	/* Admin Manage Page Get*/
	public function index()
	{
		check_user_permission();

		$sorting_array = array();

		$orderby = Request()->orderby;
		$order = Request()->order;

		if(!$orderby && !$order)
		{
			$orderby = 'id';
			$order = 'desc';
		}

		$column_array = array('id' => 'Id', 'page_name' => 'Page Name');
		$search = Request()->search;
		$where = "1 ";

		if($search)
		{
			$where .= " and (";
			$i=1;
			foreach($column_array as $key=>$val)
			{
				if($i>1)
				{
					$where .= " or ";
				}

				$where .= $key." like '%".$search."%'";
				$i++;
			}
			$where .= ")";
		}

		$item_display_per_page = config('admin.pagination');
		$pages = Page::select('pages.*')
		->whereRaw($where)
		->orderBy($orderby, $order)
		->paginate($item_display_per_page);


		foreach($column_array as $key => $value)
		{
			$sorting_class = 'sorting';
			$sorting_url_orderby = $key;
			$sorting_url_order = 'asc';

			if($orderby==$key)
			{
				$sorting_class = ( $order=='asc' ? 'sorting_asc' : 'sorting_desc' );

				$sorting_url_order = ( $order=='asc' ? 'desc' : 'asc' );
			}

			$sorting_url = 'page?'.($search!="" ? 'search='.$search.'&' : '').'orderby='.$sorting_url_orderby.'&order='.$sorting_url_order;

			$sorting_array[$key] = array('sorting_class' => $sorting_class, 'sorting_url' => $sorting_url);
		}

		return view('admin.page.index', compact('pages','column_array','sorting_array','search'));
	}


	/* Admin Add Page Get*/
	public function add()
	{
		check_user_permission();
		$all_pages = Page::get();
		return view('admin.page.add', compact('all_pages'));
	}

	/* Admin insert Page Post*/
	public function insert(Request $request)
	{
		if (!check_page_permission('page_add')) {
			return Redirect::to('admin');
		}
		$id = $request->id;

		$rules = array(
			'page_name' => 'required|string|max:255',
			'slug' => 'required|string|max:255|unique:pages',
			'display_in' => 'required|integer',
			'parent_id' => 'required|integer',
		);

		$validator = Validator::make($request->all() , $rules);

		if ($validator->fails())
		{
			return redirect()->back()->withErrors($validator)->withInput($request->all()); 
		}
		else
		{ 
			try {
				$slug = $request->slug;
				$page_name = $request->page_name;
				$page_title = $request->page_title;
				$bannertext = $request->bannertext;
				$body = $request->body;
				$body2 = $request->body2;
				$btn_text = $request->btn_text;
				$btn_url = $request->btn_url;
				$meta_keyword = $request->meta_keyword;
				$meta_description = $request->meta_description;
				$parent_id = $request->parent_id;
				$display_in = $request->display_in;
				$menu_order = $request->menu_order;

				$update_array = array('page_name' => $page_name, 'page_title' => $page_title, 'bannertext' => $bannertext, 'body' => $body, 'btn_text' => $btn_text, 'btn_url' => $btn_url, 'meta_keyword' => $meta_keyword, 'meta_description' => $meta_description, 'parent_id' => $parent_id, 'display_in' => $display_in, 'menu_order' => $menu_order);

				if ($slug) {
					$update_array['slug'] = $slug;
				}

				$page_id = DB::table('pages')->insertGetId($update_array);

				return redirect()->back()->with('success', true);

			} catch (\Exception $e) {
				DB::rollback();
				return Redirect::back()->withErrors(array('errordetailsd' => $e->getMessage()))->withInput($request->all());
			}
		}
	}

	/* Admin Update Page Get*/
	public function edit($id)
	{
		check_user_permission();
		$all_pages = Page::where('id','!=',$id)->get();
		$page = Page::where('id',$id)->get();
		$page_extra = PageExtra::where('page_id',$id)->orderBy('type', 'asc')->get();

		return view('admin.page.edit', compact('page','page_extra','all_pages'));
	}

	/* Admin Update Page Post*/
	public function update(Request $request)
	{
		if (!check_page_permission('page_edit')) {
			return Redirect::to('admin');
		}
		$id = $request->id;
		$page_extra = PageExtra::where('page_id',$id)->orderBy('type', 'asc')->get();

		$slug = $request->slug;
		$page_name = $request->page_name;
		$page_title = $request->page_title;
		$bannertext = $request->bannertext;
		$body = $request->body;
		$body2 = $request->body2;
		$btn_text = $request->btn_text;
		$btn_url = $request->btn_url;
		$meta_keyword = $request->meta_keyword;
		$meta_description = $request->meta_description;
		$parent_id = $request->parent_id;
		$display_in = $request->display_in;
		$menu_order = $request->menu_order;

		$rules = array(
			'page_name' => 'required|string|max:255',
			'slug' => 'required|string|max:255|unique:pages,slug,'.$id,
			'display_in' => 'required|integer',
			'parent_id' => 'required|integer',
		);

		if($request->hasfile('bannerimage'))
		{
			$rules['bannerimage'] = 'mimes:jpeg,png,jpg,gif,svg|max:2048';
		}

		$validator = Validator::make($request->all() , $rules);

		if ($validator->fails())
		{
			return Redirect::to('admin/page/edit/'.$id)->withErrors($validator) 
			->withInput(); 
		}
		else
		{
			foreach ($page_extra as $val) {
				$x ='section_title_'.$val->id;
				$page_extra_title = $request->$x;
				$y ='section_sub_title_'.$val->id;
				$page_extra_sub_title = $request->$y;
				$z ='section_body_'.$val->id;
				$page_extra_body = $request->$z;
				$a ='section_btn_text_'.$val->id;
				$page_extra_btn_text = $request->$a;
				$b ='section_btn_url_'.$val->id;
				$page_extra_btn_url = $request->$b;
				$update_array1 = array('title' => $page_extra_title,'body' => $page_extra_body,'sub_title' => $page_extra_sub_title,'btn_text' => $page_extra_btn_text,'btn_url' => $page_extra_btn_url);
				if($request->hasfile('section_file_'.$val->id))
				{
					if($val->image!='' && file_exists(public_path().'/uploads/'.$val->image))
					{
						unlink(public_path().'/uploads/'.$val->image);
					}
					$file = $request->file('section_file_'.$val->id);
					$filename = $file->getClientOriginalName();
					$filename = str_replace("&", "and", $filename);
					$filename = str_replace(" ", "_", $filename);
					$filename = time().$filename;
					$file->move(public_path().'/uploads/', $filename);  
					$update_array1['image'] = $filename;
				}
				if ( ( $page_extra_title=='' && $val->type==4 ) || ( $val->id!=13 && $val->type==7 && $val->image=='' ) ) {
					DB::delete('delete from pages_extra where id = ?',[$val->id]);
				}else{					
					DB::table('pages_extra')
					->where('id', $val->id)
					->update($update_array1);
				}
			}
			if ( isset($request->section_faq_new_t) && count($request->section_faq_new_t)>0) {
					$section_faq_new_t = $request->section_faq_new_t;
					$section_faq_new_c = $request->section_faq_new_c;
				for ($i=0; $i < count($request->section_faq_new_t); $i++) {
					$section_faq_new_t = $section_faq_new_t[$i];
					$section_faq_new_c = $section_faq_new_c[$i];
					DB::insert('insert into pages_extra (page_id, type, title, body) values (?, ?, ?, ?)', [$id, '4', $section_faq_new_t, $section_faq_new_c]);
				}
			}
			if ( isset($request->section_logo_new_i) && count($request->section_logo_new_i)>0) {
				if($request->hasfile('section_logo_new_i'))
				{
					foreach($request->file('section_logo_new_i') as $file){
						$filename = $file->getClientOriginalName();
						$filename = str_replace("&", "and", $filename);
						$filename = str_replace(" ", "_", $filename);
						$filename = time().$filename;
						$file->move(public_path().'/uploads/', $filename);  
						$update_array1['image'] = $filename;
						$section_logo = $filename;
						DB::insert('insert into pages_extra (page_id, type, image) values (?, ?, ?)', [$id, '7', $section_logo]);
					}
				}
			}

			$update_array = array('page_name' => $page_name, 'page_title' => $page_title, 'bannertext' => $bannertext, 'body' => $body, 'btn_text' => $btn_text, 'btn_url' => $btn_url, 'meta_keyword' => $meta_keyword, 'meta_description' => $meta_description, 'parent_id' => $parent_id, 'display_in' => $display_in, 'menu_order' => $menu_order);

			if ($slug && $id!='1' && $id!='5') {
				$update_array['slug'] = $slug;
			}

				if($request->hasfile('bannerimage'))
				{
					$page = Page::where('id',$id)->get();
					if($page[0]->bannerimage!='' && file_exists(public_path().'/uploads/'.$page[0]->bannerimage))
					{
						unlink(public_path().'/uploads/'.$page[0]->bannerimage);
					}

					$bannerimage = $request->file('bannerimage');
					$filename = $bannerimage->getClientOriginalName();
					$filename = str_replace("&", "and", $filename);
					$filename = str_replace(" ", "_", $filename);
					$filename = time().$filename;
					$bannerimage->move(public_path().'/uploads/', $filename);  
					$update_array['bannerimage'] = $filename;
				}
				if($request->hasfile('image2'))
				{
					$page = Page::where('id',$id)->get();
					if($page[0]->image2!='' && file_exists(public_path().'/uploads/'.$page[0]->image2))
					{
						unlink(public_path().'/uploads/'.$page[0]->image2);
					}

					$image2 = $request->file('image2');
					$filename = $image2->getClientOriginalName();
					$filename = str_replace("&", "and", $filename);
					$filename = str_replace(" ", "_", $filename);
					$filename = time().$filename;
					$image2->move(public_path().'/uploads/', $filename);  
					$update_array['image2'] = $filename;
				}

			DB::table('pages')
			->where('id', $id)
			->update($update_array);

			return redirect()->back()->with('success', true);

		}


	}

	/* Page Extra Fields Remove Image Get*/
	public function page_extra_remove_image($id)
	{
		if (!check_page_permission('page_edit')) {
			return Redirect::to('admin');
		}
		$pages_extra = PageExtra::where('id',$id)->get();
		if($pages_extra[0]->image!='' && file_exists(public_path().'/uploads/'.$pages_extra[0]->image))
		{
			unlink(public_path().'/uploads/'.$pages_extra[0]->image);
		}
		DB::table('pages_extra')
			->where('id', $id)
			->update( array('image' => '' ) );

		return redirect()->back()->with('remove_image_success', true);
	}

	public function delete($id)
	{
		if (!check_page_permission('page_delete')) {
			return Redirect::to('admin');
		}
		if ($id>6) {
		$page = Page::where('id',$id)->get();
		if($page[0]->bannerimage!='' && file_exists(public_path().'/uploads/'.$page[0]->bannerimage))
		{
			unlink(public_path().'/uploads/'.$page[0]->bannerimage);
		}
			DB::delete('delete from pages where id = ?',[$id]);

			return redirect()->back()->with('delete_success', true);
		}
		return Redirect::to('admin/page/')->withErrors(array('errordetailsd' => 'Nothing is deleted.'));
	}



	/* Front end*/

	/* Contact Page Get*/
	public function contact()
	{
		$setting = DB::table('av_settings')->whereIn('id', array(5, 6, 7))->get();

		$page = Page::where('id',5)->get();
		if(count($page))
		{
			if($page[0]->page_name)
			{
				// @$setting[0]->value = $page[0]->meta_title;
				@$setting[0]->value = $page[0]->page_name;
			}
			if($page[0]->meta_keyword)
			{
				@$setting[1]->value = $page[0]->meta_keyword;
			}
			if($page[0]->meta_description)
			{
				@$setting[2]->value = $page[0]->meta_description;
			}

			$page_image = '';
			$page_url = url('/'.$page[0]->slug);
			$site_logo = config('site.logo');
			if($site_logo && File::exists(public_path('uploads/'.$site_logo)) )
			{
				$page_image = url('/uploads/'.$site_logo);
			}
			return view('frontend.pages.contact', compact('page','setting','page_url','page_image'));
		}else{
			//return view('frontend.pages.contact');
			return redirect('404');
		}
		
	}

	/* Contact Page Post*/
	public function contactform(Request $request)
	{
		$name = $request->name;
		$email = $request->email;
		$message = $request->message;
		$phone = $request->phone;

		$rules = array(
			'name' => 'required',
			'email' => 'required|string|email|max:191',
			//'message' => 'required',
		);

		$validator = Validator::make($request->all() , $rules);

		if ($validator->fails())
		{
			return Redirect::to('contact')->withErrors($validator) 
			->withInput(); 
		}
		else
		{
			try {
			$admin_message = "Dear Admin,<br><br> 
			
			This e-mail was sent from the contact form on ".config('site.title')." website.<br><br>
			
			Name: ".$name."<br>
			Email: ".$email."<br>
			Phone: ".$phone."<br>
			Message: ".$message."<br><br>";

			$admin_message_content = ['content' => $admin_message];

			Mail::send('mail', $admin_message_content, function ($msg) use ($request) {

				$admin_email = config('site.contact_email');
				$support_email = config('site.support_email');

				$msg->to($admin_email)->subject(config('site.title').': Contact Us Form');
				$msg->from($support_email, $request->name);
			});
			return redirect()->back()->with('message', "Thank you for getting in touch!");
			} catch (\Exception $e) {
				DB::rollback();
				return Redirect::back()->withErrors(array('errordetailsd' => $e->getMessage()))->withInput($request->all());
			}
		}
	}

	/* Need Support Form on Help Page Post*/
	public function helpForm(Request $request)
	{
		$name = $request->name;
		$email = $request->email;
		$phone = $request->phone;
		$order_id = $request->order_id;
		$message = $request->message;

		$rules = array(
			'name' => 'required',
			'email' => 'required|string|email|max:191',
			//'message' => 'required',
		);

		$validator = Validator::make($request->all() , $rules);

		if ($validator->fails())
		{
			return redirect()->back()->withErrors($validator)->withInput(); 
		}
		else
		{
			try {
			$admin_message = "Dear Admin,<br><br> 
			
			This e-mail was sent from the help desk form on ".config('site.title')." website.<br><br>
			
			Name: ".$name."<br>
			Email: ".$email."<br>
			Phone: ".$phone."<br>
			Order Number: ".$order_id."<br>
			Message: ".$message."<br><br>";

			$admin_message_content = ['content' => $admin_message];

			Mail::send('mail', $admin_message_content, function ($msg) use ($request) {

				$admin_email = config('site.contact_email');
				$support_email = config('site.support_email');

				$msg->to($admin_email)->subject(config('site.title').': Need Support');
				$msg->from($support_email, $request->name);
			});
			return redirect()->back()->with('message', "Thank you for getting in touch!");
			} catch (\Exception $e) {
				DB::rollback();
				return Redirect::back()->withErrors(array('errordetailsd' => $e->getMessage()))->withInput($request->all());
			}
		}
	}


	/* Show Page by Slug Get*/
	public function ShowPage($slug)
	{
		$setting = DB::table('av_settings')->whereIn('id', array(5, 6, 7))->get();

		$page = Page::where('slug',$slug)->get();
		$extra_data = array();
		if(count($page))
		{
			if($page[0]->page_name)
			{
				// @$setting[0]->value = $page[0]->meta_title;
				@$setting[0]->value = $page[0]->page_name;
			}
			if($page[0]->meta_keyword)
			{
				@$setting[1]->value = $page[0]->meta_keyword;
			}
			if($page[0]->meta_description)
			{
				@$setting[2]->value = $page[0]->meta_description;
			}

			$page_image = '';
			$page_url = url('/'.$page[0]->slug);
			$site_logo = config('site.logo');
			if($site_logo && File::exists(public_path('uploads/'.$site_logo)) )
			{
				$page_image = url('/uploads/'.$site_logo);
			}
			
			if($page[0]->id=='2'){
				$extra_data = PageExtra::where('page_id',$page[0]->id)->get();
				return view('frontend.pages.about', compact('page','setting','page_url','page_image', 'extra_data'));
			}elseif($page[0]->id=='3'){
				$extra_data = PageExtra::where('page_id',$page[0]->id)->get();
				return view('frontend.pages.help', compact('page','setting','page_url','page_image', 'extra_data'));
			}
			elseif($page[0]->id=='4'){
				$extra_data = PageExtra::where('page_id',$page[0]->id)->get();
				return view('frontend.pages.work-with-us', compact('page','setting','page_url','page_image', 'extra_data'));
			}
			elseif($page[0]->id=='6'){
				//$extra_data = PageExtra::where('page_id',$page[0]->id)->get();
				return view('frontend.pages.privacy-policy', compact('page','setting','page_url','page_image'));
			}elseif($page[0]->id=='7'){
				//$extra_data = PageExtra::where('page_id',$page[0]->id)->get();
				return view('frontend.pages.terms', compact('page','setting','page_url','page_image'));
			}else{
				return view('frontend.pages.pages', compact('page','setting','page_url','page_image'));
			}
			
		}
		else
		{
			return redirect('404');
		}
	}

	/* Not Found Get*/
	public function not_found()
	{
		return view('errors.404');
	}

	/* Proofreader Register Get*/
	public function proofreader_register()
	{
		return view('auth.proofreader_register');
	}

	/* File Upload get*/
	public function file_upload()
	{
		if (Auth::check()){
			$user = currentUserDetails();
			if ($user->role_id=='3') {
				return Redirect::to('/');
			}
		}
		if(Session::has('file_upload') && file_exists(public_path().'/uploads/order/'.Session::get('file_upload')))
		{
			unlink(public_path().'/uploads/order/'.Session::get('file_upload'));
			Session::forget('file_upload');
			Session::forget('file_upload_name');
			Session::forget('price');
			Session::forget('no_of_word');
			Session::forget('notes');
		}/**/
		return view('frontend.file_upload');
	}

	/* File Upload post*/
	public function fileUpload(Request $request)
	{
		if (Auth::check()){
			$user = currentUserDetails();
			if ($user->role_id=='3') {
				return Redirect::to('/');
			}
		}
		$user_id = $request->user_id;
		$cal_price = $request->cal_price;
		$cal_eta = $request->cal_eta;
		$no_of_word = $request->no_of_word;
		$notes = $request->notes;

		$amount_charge_per_word = config('site.amount_charge_per_word');
		$price = number_format($no_of_word * $amount_charge_per_word,2, '.', '');
		$price = str_replace(',', '', $price);

		// $eta_per_word = config('site.eta_per_word');
		// $eta = $no_of_word * $eta_per_word;
		$eta = $cal_eta;

		$rules = array(
			'file_upload' => 'required|mimes:txt,doc,docx,xml,rtf,TXT,DOC,DOCX,XML,RTF|max:5140',
			'no_of_word' => 'required|integer',
		);

		$validator = Validator::make($request->all() , $rules);

		if ($validator->fails())
		{
			return Redirect::to('file-upload')->withErrors($validator)->withInput(); 
		}
		else
		{
			if($request->hasfile('file_upload'))
			{
				if(Session::has('file_upload') && file_exists(public_path().'/uploads/order/'.Session::get('file_upload')))
				{
					unlink(public_path().'/uploads/order/'.Session::get('file_upload'));
				}
				$file_upload = $request->file('file_upload');
				$filename1 = $file_upload->getClientOriginalName();
				$filename1 = str_replace("&", "and", $filename1);
				$filename1 = str_replace(" ", "_", $filename1);
				$filename2 = time().'_'.$filename1;
				$file_upload->move(public_path().'/uploads/order/', $filename2);  

				Session::put('file_upload', $filename2);
				Session::put('file_upload_name', $file_upload->getClientOriginalName());
			}
			Session::put('user_id', $user_id);
			Session::put('price', $price);
			Session::put('eta', $eta);
			Session::put('no_of_word', $no_of_word);
			Session::put('notes', $notes);
		}
		return Redirect::to('place-order');
	}

	/* Place Order with payment get*/
	public function place_order()
	{
		if (!Session::has('file_upload') || !file_exists(public_path().'/uploads/order/'.Session::get('file_upload'))){
			return Redirect::to('file-upload');
		}
		if (Auth::check()){
			$user = currentUserDetails();
			if ($user->role_id=='3') {
				return Redirect::to('/');
			}
			Session::put('user_id', $user->id);
		}
		return view('frontend.place_order');
	}

	/* Place Order with payment post*/
	public function placeOrder(Request $request)
	{
		if (Auth::check()){
			$user = currentUserDetails();
			if ($user->role_id=='3') {
				return Redirect::to('/');
			}
		}

		$rules = array(
            'first_name' => 'required|string|max:191',
            'last_name' => 'required|string|max:191',
            'card_no' => 'required',
            'exp' => 'required',
            'cvv' => 'required',
		);
		if (Auth::check()) {
			$rules['email'] = 'required|string|email|max:191';
		}else{
			$rules['email'] = 'required|string|email|max:191|unique:users';
		}

		$validator = Validator::make($request->all() , $rules);

		if ($validator->fails())
		{
			return Redirect::to('place-order')->withErrors($validator)->withInput(); 
		}
		else
		{
			$first_name = $request->first_name;
			$last_name = $request->last_name;
			$email = $request->email;
			$role_id = 4;
			$password = random_strings();

			$card_no = trim($request->card_no);
			$card_no = str_replace('-', '', $card_no);
			$exp = $request->exp;
			$exp = explode('/', $exp);
			$exp_month = trim($exp[0]);
			$exp_year = '20'.trim($exp[1]);
			$cvv = $request->cvv;

			$upload_file = Session::get('file_upload');
			$no_of_word = Session::get('no_of_word');
			$notes = Session::get('notes');
			$price = Session::get('price');
			$eta = Session::get('eta');
			$subtotal_amount = $price;
			$total_amount = $price;
			$currency = $_SESSION['currency'];

			$amount_charge_per_word = config('site.amount_charge_per_word');
			$price = round($no_of_word * $amount_charge_per_word,2);

			// $stripe = Stripe::setApiKey(env('STRIPE_SECRET'));
			$stripe = Stripe::make(config('app.STRIPE_SECRET'));
			try {
				$token = $stripe->tokens()->create([
					'card' => [
					'number' => $card_no,
					'exp_month' => $exp_month,
					'exp_year' => $exp_year,
					'cvc' => $cvv,
					],
				]);
				if (!isset($token['id'])) {
					return Redirect::back()->withErrors(array('errordetailsd' => 'Invalid card! Please enter valid card.'))->withInput();
				}
				$charge = $stripe->charges()->create([
					'card' => $token['id'],
					'currency' => strtoupper($currency),
					'amount' => $total_amount,
					'description' => 'Anoview Order',
				]);
 
				if($charge['status'] == 'succeeded') {
					$amount = $charge['amount']/100;
			if (Auth::check()) {
				$user = currentUserDetails();
				$user_id = $user->id;
			}else{
		        $user = new User();
		        $user->role_id = $role_id;
		        $user->first_name = $first_name;
		        $user->last_name = $last_name;
		        $user->email = $email;
		        $user->password = Hash::make($password);
		        $user->status = '1';
		        $user->last_activity = date('Y-m-d H:i:s');
				$user->email_verified_at = date('Y-m-d H:i:s');
		        $user->save();

		        $user['fullname'] = $first_name.' '.$last_name;
		        $user['password'] = $password;
		        Mail::to($email)->send(new WelcomeMail($user));

		        $userdata = array(
					'email' => $email ,
					'password' => $password
				);

		        // Auth::attempt($userdata);
		        if ($user->id>0){
		        	$user_id = $user->id;
		        	Auth::loginUsingId($user_id);
		        }
			}

					$order = new Order();
					$order->upload_file = $upload_file;
					$order->no_of_word = $no_of_word;
					$order->notes = $notes;
					$order->eta = $eta;
					$order->user_id = $user_id;
					$order->billing_first_name = $first_name;
					$order->billing_last_name = $last_name;
					$order->billing_email = $email;
					$order->status = '1';
					$order->payment_status = '1';
					$order->currency = $currency;
					$order->subtotal_amount = $subtotal_amount;
					$order->total_amount = $total_amount;
					$order->save();

					$transaction_id = $charge['id'];

					$transaction = new Transaction();
					$transaction->order_id = $order->id;
					$transaction->user_id = $user_id;
					$transaction->name = $first_name.' '.$last_name;
					$transaction->transaction_id = $transaction_id;
					$transaction->currency = $currency;
					$transaction->amount = $amount;
					$transaction->payment_through = '1';
					$transaction->transaction_date = date('Y-m-d H:i:s');
					$transaction->save();

					Session::put('order_id', $order->id);
					Session::forget('file_upload');
					Session::forget('file_upload_name');
					Session::forget('price');
					Session::forget('eta');
					Session::forget('no_of_word');
					Session::forget('notes');

					$data1 = array('fullname' => $first_name.' '.$last_name, 'first_name' => $first_name, 'email' => $email, 'order_id' => get_orderID($order->id));
		        	Mail::to($email)->send(new OrderMail($data1));

					/*Order Email to Admin*/
					if (config('site.order_email_option')=='yes') {
						$admin_email = config('site.order_email');
			        	$data1 = array('fullname' => $first_name.' '.$last_name, 'first_name' => $first_name, 'email' => $email, 'order_id' => get_orderID($order->id));
			        	Mail::to($admin_email)->send(new OrderMailToAdmin($data1));
					}

					/*echo "<pre>";
					print_r($charge);
					echo "</pre>";
					exit();*/
					return Redirect::to('find-proofreader');
				} else {
					return Redirect::back()->withErrors(array('errordetailsd' => 'Money not add in wallet!!'))->withInput();
				}
			} catch (Exception $e) {
				return Redirect::back()->withErrors(array('errordetailsd' => $e->getMessage()))->withInput();
			} catch(\Cartalyst\Stripe\Exception\CardErrorException $e) {
				return Redirect::back()->withErrors(array('errordetailsd' => $e->getMessage()))->withInput();
			} catch(\Cartalyst\Stripe\Exception\MissingParameterException $e) {
				return Redirect::back()->withErrors(array('errordetailsd' => $e->getMessage()))->withInput();
			}
		}
	}

}