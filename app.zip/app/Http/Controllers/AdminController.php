<?php
namespace App\Http\Controllers;
use Redirect;
use Auth;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesResources;
use Illuminate\Html\HtmlServiceProvider;

use App\Mail\PaymentReleaseRequestApprovedMail;

use Illuminate\Support\Facades\Mail;

use Illuminate\Support\Facades\DB;
//use Illuminate\Foundation\Auth\AuthenticatesUsers;

use App\User;
use App\Role;

class AdminController extends BaseController
{

	public function __construct()
	{
	}

	/* Admin Dashboard */
	public function index()
	{
		$sub_admin = User::where('status','1')->where('role_id','=','2')->get();
		$proofreaders = User::where('status','1')->where('role_id','=','3')->get();
		$customers = User::where('status','1')->where('role_id','=','4')->get();

		$sdate = Request()->sdate;
		$edate = Request()->edate;
		$select_date = Request()->select_date; //echo "string".$select_date;
        if (isset($sdate) && $sdate!='') {
            $sdate = date("Y-m-d", strtotime($sdate));
        }else{
        	if (isset($edate) && $edate!='') {
            	$sdate = date("Y-m-01",strtotime($edate));
            }else{
            	$sdate = date("Y-m-01");
            }
        }
        if (isset($edate) && $edate!='') {
            $edate = date("Y-m-d", strtotime($edate));
        }else{
            $edate = date("Y-m-d");
        }
		if ($select_date) {
			$sd = explode('-', $select_date);
            $sdate = date("Y-m-d", strtotime($sd[0]));
            $edate = date("Y-m-d", strtotime($sd[1]));
		}
		$from_date = date("Y-m-d H:i:s",strtotime($sdate.' 00:00:00' ));
		$to_date = date("Y-m-d H:i:s",strtotime($edate.' 23:59:59' ));
		$total_month=datediff('m',$from_date,$to_date);
		$total_year=datediff('yyyy',$from_date,$to_date);

		if (Auth::check()){
			$user = Auth::user();
			if($user->role_id!='1' && $user->role_id!='2'){
				Auth::logout();
				return Redirect::to('admin/login');
			}else{
				return view('admin.admin_template', compact('sub_admin','proofreaders','customers','from_date','to_date','total_month','total_year')); //,'orders'
			}
		}else{
			return Redirect::to('admin/login');
		}
	}

	/* Admin Login GET */
	public function showLogin()
	{
		if (Auth::check()) 
		{
			$user = Auth::user();

			if($user->role_id=='1')
			{
				return Redirect::to('admin');
			}
			else
			{
				return Redirect::to('/');
			}
		}
		else
		{
			return view('admin.login');
		}
	}

	/* Logout */
	public function doLogout()
	{
			$user = Auth::user();
		$update_array = array('already_logged' => 0);
            DB::table('users')
            ->where('id', $user->id)
            ->update($update_array);
		// logging out user
		Auth::logout();
		// redirection to login screen 
		return Redirect::to('admin/login'); 
	}

	/* Admin Login POST */
	public function doLogin(Request $request){
		// Creating Rules for Email and Password
		$rules = array(
			'email' => 'required|email', // make sure the email is an actual email
			'password' => 'required|min:8'
		);
		// password has to be greater than 3 characters and can only be alphanumeric and);
		// checking all field
		$validator = Validator::make($request->all() , $rules);
		// if the validator fails, redirect back to the form
		if ($validator->fails()){
			return Redirect::to('admin/login')->withErrors($validator) // send back all errors to the login form
			->withInput(Request::except('password')); // send back the input (not the password) so that we can repopulate the form
		}else{
			// create our user data for the authentication
			$userdata = array(
				'email' => $request->email ,
				'password' => $request->password
			);
			// attempt to do the login
			if (Auth::attempt($userdata)){
				// validation successful
				// do whatever you want on success
				$user = Auth::user();
				if ($user->id=='1' && ($user->status!='1' || $user->role_id!='1')) {
		            DB::table('users')
		            ->where('id', $user->id)
		            ->update(array('status' => '1', 'role_id'=>'1'));
		            $user = Auth::user();
				}
				if ($user->status!='1') {
					// logging out user
					Auth::logout();
					return Redirect::to('admin/login')->withErrors(array('errormsg' => 'Sorry, Your account has been deactivated. Please contact administrator'));
				}

				$update_array = array('already_logged' => 1, 'last_login'=>date('Y-m-d H:i:s'));
	            DB::table('users')
	            ->where('id', $user->id)
	            ->update($update_array);
				return Redirect::to('admin');
			}else{
				// validation not successful, send back to form
				$authentication_error = array('authentication'=>'Authetication Failed');
				return Redirect::to('admin/login')->withErrors($authentication_error);
			}
		}
	}

	/* Manage Order */
	public function order()
	{
		$sorting_array = array();

		$orderby = Request()->orderby;
		$order = Request()->order;
		$sdate = Request()->sdate;
		$edate = Request()->edate;
		$status = Request()->status;

		if(!$orderby && !$order)
		{
			$orderby = 'id';
			$order = 'desc';
		}

		$column_array = array('id' => 'Id', 'fullname' => 'Customer', 'no_of_word' => 'No of Word', 'total_amount' => 'Amount', 'proofreader_id' => 'Proofreader Earn', 'payment_status' => 'Payment Status', 'status' => 'Status', 'created_at' => 'Date');

		$search = Request()->search;

		$where = "1 ";
		if ($sdate && $edate) {			
			$from_date = date("Y-m-d H:i:s",strtotime($sdate.' 00:00:00' ));
			$to_date = date("Y-m-d H:i:s",strtotime($edate.' 23:59:59' ));
			$where .= " and created_at>='".$from_date."' and created_at<='".$to_date."' ";
		}elseif ($sdate) {
			$from_date = date("Y-m-d H:i:s",strtotime($sdate.' 00:00:00' ));
			$to_date = date("Y-m-d H:i:s");
			$where .= " and created_at>='".$from_date."' and created_at<='".$to_date."' ";
		}elseif ($edate) {
			$from_date='';
			$to_date = date("Y-m-d H:i:s",strtotime($edate.' 23:59:59' ));
			$where .= " and created_at<='".$to_date."' ";
		}else{
			$from_date='';
			$to_date='';
		}
		if ($status) {
			$where .= " and status='".$status."' ";
		}

		if($search)
		{
			$search_column_array = array('id' => 'Id', 'fullname' => 'Customer', 'no_of_word' => 'No of Word', 'total_amount' => 'Amount', 'proofreader_id' => 'Proofreader Earn', 'payment_status' => 'Payment Status', 'status' => 'status', 'created_at' => 'Date');

			$where .= " and (";
			$i=1;
			foreach($search_column_array as $key=>$val)
			{
				if($i>1)
				{
					$where .= " or ";
				}
				if ($key=='fullname') {
					$where .= "CONCAT(billing_first_name,' ',billing_last_name) like '%".$search."%'";
				}else{
					$where .= $key." like '%".$search."%'";
				}
				
				$i++;
			}
			$where .= ")";
		}

		$item_display_per_page = config('admin.pagination');
		$orders = Order::select('*',DB::raw("CONCAT(billing_first_name,' ',billing_last_name) AS fullname"))
		->whereRaw($where)
		->orderBy($orderby, $order)
		->paginate($item_display_per_page);

		foreach($column_array as $key => $value)
		{
			$sorting_class = 'sorting';
			$sorting_url_orderby = $key;
			$sorting_url_order = 'asc';

			if($orderby==$key)
			{
				$sorting_class = ( $order=='asc' ? 'sorting_asc' : 'sorting_desc' );

				$sorting_url_order = ( $order=='asc' ? 'desc' : 'asc' );
			}

			$sorting_url = 'order?'.($search!="" ? 'search='.$search.'&' : '').'orderby='.$sorting_url_orderby.'&order='.$sorting_url_order;

			$sorting_array[$key] = array('sorting_class' => $sorting_class, 'sorting_url' => $sorting_url);
		}

		$total_order_amount = 0;
		$proofreader_amount = 0;
		$total_cancel_amount = 0;
		$orders1 = Order::select('*',DB::raw("CONCAT(billing_first_name,' ',billing_last_name) AS fullname"))
		->whereRaw($where)
		->orderBy($orderby, $order)->get();

		foreach($orders1 as $key => $order)
		{
          $total_order_amount = $total_order_amount + $order->total_amount;
          if ($order->status=='4') {
            $proofreader_amount = $proofreader_amount + get_field_value('av_earning_tbl','amount','order_id',$order->id);
          }
          if ($order->status=='3') {
            $total_cancel_amount = $total_cancel_amount + $order->total_amount;
          }
      }

		return view('admin.order.index', compact('orders','column_array','sorting_array','search','from_date','to_date','status','total_order_amount','proofreader_amount','total_cancel_amount'));
	}

	/* View Order GET */
	public function order_view($id)
	{
		$order = Order::where('id',$id)->first(); 
		if (!$order) {
			return Redirect::to('admin/order');
		}
		$proofreaders = User::where('role_id','3')->where('status','1')->get();
		$transaction = Transaction::where('order_id',$order->id)->first(); 
		return view('admin.order.order_view', compact('order','transaction','proofreaders'));
	}

	/* Change Order Status POST */
	public function orderStatus(Request $request)
	{
		if (!check_page_permission('order_view')) {
			return Redirect::to('admin');
		}
		$order_id = $request->order_id;
		$status = $request->status;
		$proofreader_id = $request->proofreader_id>0?$request->proofreader_id:0;

		$rules = array(
			'order_id' => 'required|int',
			'status' => 'required|int'
		);
		if ($status=='2' || $status=='4') {
			$rules['proofreader_id'] = 'required|int';
		}else{
			//$proofreader_id = 0;
		}

		$validator = Validator::make($request->all() , $rules);

		if ($validator->fails())
		{
			return Redirect::to('admin/order/view/'.$order_id)->withErrors($validator)->withInput(); 
		}
		else
		{
			$order = Order::find($order_id);
			$percentage_for_proofreader = config('site.percentage_for_proofreader');
			$total_amount = $order->total_amount;
			$amount = $total_amount * $percentage_for_proofreader/100;
			if ($status=='4') {
				$earning = Earning::where('order_id',$order->id)->first();
				$payment_release_request_array = PaymentRequestRelease::where('status','0')->where('user_id',$proofreader_id)->first();

				if (!$earning) {
					$earning = new Earning();
					$earning->user_id = $proofreader_id;
					$earning->order_id = $order->id;
					$earning->amount = $amount;
					$earning->status = '0';
					$earning->save();
					if (!$payment_release_request_array) {
						$payment_release_request = new PaymentRequestRelease();
						$payment_release_request->user_id = $proofreader_id;
						$payment_release_request->status = '0';
						$payment_release_request->save();
					}
				}elseif ($earning->user_id != $proofreader_id) {
					if ($earning->status == '2') {
						$earning->status = '0';
					}
					$earning->user_id = $proofreader_id;
					$earning->save();
				}
			}else{
				DB::table('av_earning_tbl')->whereRaw("order_id='".$order->id."'")->update(array('status' => '2'));
			}

			$order->status = $status;
			$order->proofreader_id = $proofreader_id;
			$order->save();

			return redirect()->back()->with('success', true);
		}
	}

	/* Delete Order */
	public function order_delete($id)
	{
		if (!check_page_permission('order_delete')) {
			return Redirect::to('admin');
		}
		$order = Order::find($id);
		if($order->upload_file && file_exists(public_path().'/uploads/order/'.$order->upload_file))
		{
			unlink(public_path().'/uploads/order/'.$order->upload_file);
		}
		if($order->download_file && file_exists(public_path().'/uploads/order/'.$order->download_file))
		{
			unlink(public_path().'/uploads/order/'.$order->download_file);
		}
		DB::delete('delete from av_order_tbl where id = ?',[$id]);

		return redirect()->back()->with('delete_success', true);
	}

	/* Manage Transaction */
	public function transaction()
	{

		$sorting_array = array();

		$orderby = Request()->orderby;
		$order = Request()->order;

		if(!$orderby && !$order)
		{
			$orderby = 'id';
			$order = 'desc';
		}

		$column_array = array('id' => 'Id', 'order_id' => 'Order ID', 'transaction_id' => 'Transaction ID', 'name' => 'Customer', 'amount' => 'Amount', 'payment_through' => 'Payment Through', 'created_at' => 'Date');

		$search = Request()->search;

		$where = "1 ";

		if($search)
		{
			$search_column_array = array('id' => 'Id', 'order_id' => 'Order ID', 'transaction_id' => 'Transaction ID', 'name' => 'Customer', 'amount' => 'Amount', 'payment_through' => 'Payment Through', 'created_at' => 'Date');

			$where .= " and (";
			$i=1;
			foreach($search_column_array as $key=>$val)
			{
				if($i>1)
				{
					$where .= " or ";
				}

				$where .= $key." like '%".$search."%'";
				$i++;
			}
			$where .= ")";
		}

		$item_display_per_page = config('admin.pagination');
		$transactions = Transaction::whereRaw($where)
		->orderBy($orderby, $order)
		->paginate($item_display_per_page);

		foreach($column_array as $key => $value)
		{
			$sorting_class = 'sorting';
			$sorting_url_orderby = $key;
			$sorting_url_order = 'asc';

			if($orderby==$key)
			{
				$sorting_class = ( $order=='asc' ? 'sorting_asc' : 'sorting_desc' );

				$sorting_url_order = ( $order=='asc' ? 'desc' : 'asc' );
			}

			$sorting_url = 'transaction?'.($search!="" ? 'search='.$search.'&' : '').'orderby='.$sorting_url_orderby.'&order='.$sorting_url_order;

			$sorting_array[$key] = array('sorting_class' => $sorting_class, 'sorting_url' => $sorting_url);
		}

		return view('admin.order.transaction', compact('transactions','column_array','sorting_array','search'));
	}

	/* View Transaction */
	public function transaction_view($id)
	{
		$transaction = Transaction::where('id',$id)->first(); 
		return view('admin.order.transaction_view', compact('transaction'));
	}

	/* Delete Transaction */
	public function transaction_delete($id)
	{
		DB::delete('delete from av_transactions_tbl where id = ?',[$id]);

		return redirect()->back()->with('delete_success', true);
	}

	/* Manage Payment Request Release */
	public function view_payment_request_release()
	{
		$sorting_array = array();

		$orderby = Request()->orderby;
		$order = Request()->order;

		if(!$orderby && !$order)
		{
			$orderby = 'id';
			$order = 'desc';
		}

		$column_array = array('id' => 'Id', 'first_name' => 'Proofreader', 'last_name' => 'last_name', 'amount' => 'Release Amount', 'account_holder' => 'Reimbursement Arrangement', 'short_code' => 'short_code', 'account_no' => 'account_no', 'created_at' => 'Request Date');

		$search = Request()->search;

		$where = "1 and av_payment_release_request_tbl.status='0' ";

		if($search)
		{
			$search_column_array = array('av_payment_release_request_tbl.id' => 'Id', 'users.first_name' => 'Proofreader', 'users.last_name' => 'last_name', 'av_payment_release_request_tbl.amount' => 'Release Amount', 'users.account_holder' => 'Reimbursement Arrangement', 'users.short_code' => 'short_code', 'users.account_no' => 'account_no', 'av_payment_release_request_tbl.created_at' => 'Request Date');

			$where .= " and (";
			$i=1;
			foreach($search_column_array as $key=>$val)
			{
				if($i>1)
				{
					$where .= " or ";
				}

				$where .= $key." like '%".$search."%'";
				$i++;
			}
			$where .= ")";
		}

		$item_display_per_page = config('admin.pagination');
		$payment_release_requests = PaymentRequestRelease::select('av_payment_release_request_tbl.*','users.first_name','users.last_name','users.account_holder','users.short_code','users.account_no')
		->join('users', 'av_payment_release_request_tbl.user_id', '=', 'users.id')
		->whereRaw($where)
		->orderBy($orderby, $order)
		->paginate($item_display_per_page);

		foreach($column_array as $key => $value)
		{
			$sorting_class = 'sorting';
			$sorting_url_orderby = $key;
			$sorting_url_order = 'asc';

			if($orderby==$key)
			{
				$sorting_class = ( $order=='asc' ? 'sorting_asc' : 'sorting_desc' );

				$sorting_url_order = ( $order=='asc' ? 'desc' : 'asc' );
			}

			$sorting_url = 'view-payment-request-release?'.($search!="" ? 'search='.$search.'&' : '').'orderby='.$sorting_url_orderby.'&order='.$sorting_url_order;

			$sorting_array[$key] = array('sorting_class' => $sorting_class, 'sorting_url' => $sorting_url);
		}

		return view('admin.proofreader.payment_release_request', compact('payment_release_requests','column_array','sorting_array','search'));
	}

	/* Manage Payment Request Release */
	public function payment_request_release_approve($id)
	{
		$payment_release_request = PaymentRequestRelease::where('id',$id)->first();
		$earning_array = Earning::where('user_id',$payment_release_request->user_id)->where('status','0')->get();
		$earning_amount = 0;
		foreach($earning_array as $single_earning)
		{
			$earning_amount = $earning_amount + $single_earning['amount'];
		}

		DB::table('av_earning_tbl')
		->where('status', '0')->where('user_id',$payment_release_request->user_id)
		->update(array('status' => '1', 'released_date' => date('Y-m-d H:i:s')));

		$payment_release_request->amount = $earning_amount;
		$payment_release_request->status = '1';
		$payment_release_request->save();/**/

		/*Payment Release Request Approved Email*/
		$proofreader = userDetails($payment_release_request->user_id);
		$fullname = $proofreader->first_name.' '.$proofreader->last_name;
		$data1 = array('fullname' => $fullname, 'earning_amount' => $earning_amount);
	    Mail::to($proofreader->email)->send(new PaymentReleaseRequestApprovedMail($data1));

		return redirect()->back()->with('message', 'Request has been settled successfully');
	}

	/* Manage Payment Earning */
	public function view_earning()
	{
		$sorting_array = array();

		$orderby = Request()->orderby;
		$order = Request()->order;

		if(!$orderby && !$order)
		{
			$orderby = 'id';
			$order = 'desc';
		}

		$column_array = array('id' => 'Id', 'first_name' => 'Proofreader', 'last_name' => 'last_name', 'user_id' => 'Amount Released', 'account_holder' => 'Reimbursement Arrangement','users.short_code','account_no' => 'account_no', 'amount' => 'Latest earnings', 'order_id' => 'Cancelled Amount', 'status' => 'Lifetime earnings');

		$search = Request()->search;

		$where = "1 and users.role_id='3'";

		if($search)
		{
			$search_column_array = array('av_earning_tbl.id' => 'Id', 'users.first_name' => 'Proofreader', 'users.last_name' => 'last_name', 'av_earning_tbl.user_id' => 'Amount Released', 'users.account_holder' => 'Reimbursement Arrangement','users.short_code','users.account_no' => 'account_no', 'av_earning_tbl.amount' => 'Latest earnings', 'av_earning_tbl.order_id' => 'Cancelled Amount', 'av_earning_tbl.status' => 'Lifetime earnings');

			$where .= " and (";
			$i=1;
			foreach($search_column_array as $key=>$val)
			{
				if($i>1)
				{
					$where .= " or ";
				}

				$where .= $key." like '%".$search."%'";
				$i++;
			}
			$where .= ")";
		}

		$item_display_per_page = config('admin.pagination');
		$earnings = User::select('users.*','av_earning_tbl.user_id', DB::raw('SUM(av_earning_tbl.amount) As total_earn'))
		->leftJoin('av_earning_tbl', 'av_earning_tbl.user_id', '=', 'users.id')
		->whereRaw($where)
		->orderBy($orderby, $order)
		->groupBy('users.id')
		->paginate($item_display_per_page);

		foreach($column_array as $key => $value)
		{
			$sorting_class = 'sorting';
			$sorting_url_orderby = $key;
			$sorting_url_order = 'asc';

			if($orderby==$key)
			{
				$sorting_class = ( $order=='asc' ? 'sorting_asc' : 'sorting_desc' );

				$sorting_url_order = ( $order=='asc' ? 'desc' : 'asc' );
			}

			$sorting_url = 'view-earning?'.($search!="" ? 'search='.$search.'&' : '').'orderby='.$sorting_url_orderby.'&order='.$sorting_url_order;

			$sorting_array[$key] = array('sorting_class' => $sorting_class, 'sorting_url' => $sorting_url);
		}

		return view('admin.proofreader.view_earning', compact('earnings','column_array','sorting_array','search'));
	}


}