<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StaticPage extends Model
{
    //protected $table = 'av_static_page';
    protected $table = 'pages';
}
